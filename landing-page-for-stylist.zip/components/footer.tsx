import Link from "next/link"

export function Footer() {
  return (
    <footer className="py-12 bg-primary text-primary-foreground">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <Link href="/" className="text-xl font-semibold tracking-wider">
            ÉLISE LAURENT
          </Link>
          <p className="text-sm text-primary-foreground/70 tracking-wide">
            © 2026 Élise Laurent. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-6">
            <Link
              href="#"
              className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors"
            >
              Privacidad
            </Link>
            <Link
              href="#"
              className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors"
            >
              Términos
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
