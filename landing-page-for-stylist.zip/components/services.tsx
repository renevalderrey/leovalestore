import { Scissors, Sparkles, Palette, Crown } from "lucide-react"

const services = [
  {
    icon: Scissors,
    title: "Corte Signature",
    description: "Corte personalizado diseñado exclusivamente para realzar tus facciones y estilo de vida.",
    price: "€120",
    duration: "90 min",
  },
  {
    icon: Palette,
    title: "Coloración Artística",
    description: "Técnicas avanzadas de coloración con productos premium para un resultado natural y duradero.",
    price: "€180",
    duration: "150 min",
  },
  {
    icon: Sparkles,
    title: "Tratamiento Luxury",
    description: "Ritual de hidratación profunda con ingredientes exclusivos para un cabello radiante.",
    price: "€95",
    duration: "60 min",
  },
  {
    icon: Crown,
    title: "Peinado Evento",
    description: "Looks sofisticados para ocasiones especiales, bodas y eventos de alta gama.",
    price: "€200",
    duration: "120 min",
  },
]

export function Services() {
  return (
    <section id="servicios" className="py-24 md:py-32 bg-card">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-20">
          <p className="text-sm tracking-[0.3em] uppercase text-muted-foreground mb-4">Servicios</p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light text-card-foreground mb-6">
            Experiencias <span className="italic">exclusivas</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Cada servicio es una experiencia única, diseñada para superar tus expectativas y revelar tu mejor versión.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {services.map((service, index) => (
            <div
              key={index}
              className="group p-8 md:p-10 border border-border bg-background hover:border-accent transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-6">
                <service.icon className="w-8 h-8 text-accent" strokeWidth={1.5} />
                <div className="text-right">
                  <span className="text-3xl font-light text-foreground">{service.price}</span>
                  <p className="text-xs tracking-widest uppercase text-muted-foreground mt-1">{service.duration}</p>
                </div>
              </div>
              <h3 className="text-2xl font-medium text-foreground mb-3 group-hover:text-accent transition-colors">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-6">¿Buscas algo más personalizado?</p>
          <a
            href="#contacto"
            className="inline-flex items-center gap-2 text-sm tracking-widest uppercase text-foreground border-b border-foreground pb-1 hover:text-accent hover:border-accent transition-colors"
          >
            Consulta privada
          </a>
        </div>
      </div>
    </section>
  )
}
