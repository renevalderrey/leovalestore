import { MapPin, Phone, Mail, Instagram } from "lucide-react"

export function Contact() {
  return (
    <section id="contacto" className="py-24 md:py-32 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 max-w-6xl mx-auto">
          {/* Contact Info */}
          <div>
            <p className="text-sm tracking-[0.3em] uppercase text-muted-foreground mb-4">Contacto</p>
            <h2 className="text-4xl md:text-5xl font-light text-secondary-foreground mb-6">
              Hablemos de tu <span className="italic">transformación</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-10">
              Cada visita comienza con una consulta personalizada para entender tu estilo, necesidades y expectativas.
              Reserva tu cita y comencemos juntos este viaje.
            </p>

            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center border border-border">
                  <MapPin className="w-5 h-5 text-accent" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs tracking-widest uppercase text-muted-foreground mb-1">Ubicación</p>
                  <p className="text-secondary-foreground">Calle Serrano 42, Madrid</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center border border-border">
                  <Phone className="w-5 h-5 text-accent" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs tracking-widest uppercase text-muted-foreground mb-1">Teléfono</p>
                  <p className="text-secondary-foreground">+34 912 345 678</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center border border-border">
                  <Mail className="w-5 h-5 text-accent" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs tracking-widest uppercase text-muted-foreground mb-1">Email</p>
                  <p className="text-secondary-foreground">hola@eliselaurent.com</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center border border-border">
                  <Instagram className="w-5 h-5 text-accent" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs tracking-widest uppercase text-muted-foreground mb-1">Instagram</p>
                  <p className="text-secondary-foreground">@eliselaurent.studio</p>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div id="reservar" className="bg-card p-8 md:p-10 border border-border">
            <h3 className="text-2xl font-medium text-card-foreground mb-8">Reservar Cita</h3>
            <form className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-xs tracking-widest uppercase text-muted-foreground block mb-2">Nombre</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent transition-colors"
                    placeholder="Tu nombre"
                  />
                </div>
                <div>
                  <label className="text-xs tracking-widest uppercase text-muted-foreground block mb-2">Teléfono</label>
                  <input
                    type="tel"
                    className="w-full px-4 py-3 bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent transition-colors"
                    placeholder="+34 600 000 000"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs tracking-widest uppercase text-muted-foreground block mb-2">Email</label>
                <input
                  type="email"
                  className="w-full px-4 py-3 bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent transition-colors"
                  placeholder="tu@email.com"
                />
              </div>
              <div>
                <label className="text-xs tracking-widest uppercase text-muted-foreground block mb-2">Servicio</label>
                <select className="w-full px-4 py-3 bg-background border border-input text-foreground focus:outline-none focus:border-accent transition-colors">
                  <option value="">Selecciona un servicio</option>
                  <option value="corte">Corte Signature</option>
                  <option value="coloracion">Coloración Artística</option>
                  <option value="tratamiento">Tratamiento Luxury</option>
                  <option value="evento">Peinado Evento</option>
                  <option value="consulta">Consulta Personalizada</option>
                </select>
              </div>
              <div>
                <label className="text-xs tracking-widest uppercase text-muted-foreground block mb-2">Mensaje</label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-3 bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent transition-colors resize-none"
                  placeholder="Cuéntame sobre tus expectativas..."
                />
              </div>
              <button
                type="submit"
                className="w-full py-4 bg-primary text-primary-foreground text-sm tracking-widest uppercase hover:bg-primary/90 transition-colors"
              >
                Solicitar Cita
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
